package com.example.fooddeliveryproject.respository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.fooddeliveryproject.model.Category;

public interface CategoryRepository extends JpaRepository<Category,Long>{

}
