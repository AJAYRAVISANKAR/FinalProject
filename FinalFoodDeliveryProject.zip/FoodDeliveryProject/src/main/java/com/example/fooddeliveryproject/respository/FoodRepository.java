package com.example.fooddeliveryproject.respository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

//import com.example.fooddeliveryproject.model.Category;
import com.example.fooddeliveryproject.model.Food;


	public interface FoodRepository extends JpaRepository<Food,Long>{
		List<Food> findByCategoryCategoryId(long categoryId);
}
