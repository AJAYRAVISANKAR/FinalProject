package com.example.fooddeliveryproject.respository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.fooddeliveryproject.model.Cart;
//import com.example.fooddeliveryproject.model.Category;

	@Repository
	public interface CartRepository extends JpaRepository<Cart,Long>{
	
		List<Cart> findByUserEmailID(String userEmailID);
	


	//public Object findById(long cartId);
}