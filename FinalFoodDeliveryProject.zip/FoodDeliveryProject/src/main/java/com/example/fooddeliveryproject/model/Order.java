package com.example.fooddeliveryproject.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "OrderTable")

public class Order {
	@Id
	//@Generated
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	@Column(name = "Order_ID")
	private long orderId;
	//@Column(name = "Email_ID")
	//private String emailId;
	@Column(name = "Cart_ID")
	private long cartId;
	@Column(name = "Total")
	private float total;
	
	public Order()
	{
		
	}
	@ManyToOne( cascade=CascadeType.MERGE)
	@JoinColumn(name="categoryId")
	@JsonIgnore
	@OnDelete(action=OnDeleteAction.CASCADE)
	private Category category;

	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public long getCartId() {
		return cartId;
	}

	public void setCartId(long cartId) {
		this.cartId = cartId;
	}

	public float getTotal() {
		return total;
	}

	public void setTotal(float total) {
		this.total = total;
	}

	public Order(long orderId, long cartId, float total) {
		super();
		this.orderId = orderId;
		this.cartId = cartId;
		this.total = total;
	}
	
}