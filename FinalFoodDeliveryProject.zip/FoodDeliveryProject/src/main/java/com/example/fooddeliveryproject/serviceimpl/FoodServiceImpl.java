package com.example.fooddeliveryproject.serviceimpl;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.fooddeliveryproject.exception.UserNotFoundException;
import com.example.fooddeliveryproject.model.Category;
//import com.example.fooddeliveryproject.model.Category;
import com.example.fooddeliveryproject.model.Food;
//import com.example.fooddeliveryproject.respository.CategoryRepository;
import com.example.fooddeliveryproject.respository.FoodRepository;
import com.example.fooddeliveryproject.service.CategoryService;
import com.example.fooddeliveryproject.service.FoodService;

@Service
public class FoodServiceImpl implements FoodService {

	@Autowired
	private FoodRepository foodRepository;
	private CategoryService categoryService;
	
	

	public FoodServiceImpl(FoodRepository foodRepository, CategoryService categoryService) {
		super();
		this.foodRepository = foodRepository;
		this.categoryService = categoryService;
	}

	@Override
	public Food saveFood(Food food) {
		// TODO Auto-generated method stub
		//System.out.println("In service"+ food);
		return foodRepository.save(food);
	}

	@Override
	public List<Food> getFood() {
		// TODO Auto-generated method stub
		return foodRepository.findAll()  ;
	}

	@Override
	public Food getFoodById(long foodId) {
		// TODO Auto-generated method stub
		return foodRepository.findById(foodId).orElseThrow(()->new UserNotFoundException("Food","FoodId",foodId)); 
	}
	@Override
	public List<Food> getFoodByCategoryId(long categoryId) {
		// TODO Auto-generated method stub
		Category category=categoryService.getCategoryByID(categoryId);
		return foodRepository.findByCategoryCategoryId(categoryId);
	}

	
	

	@Override
	public void deleteFoodById(long foodId) {
		// TODO Auto-generated method stub
		foodRepository.findById(foodId).orElseThrow(()->new UserNotFoundException("Food","FoodId",foodId)); 
		foodRepository.deleteById(foodId);
	}

	@Override
	public Food addFoodToCategory(Food food, long categoryId) {
		// TODO Auto-generated method stub
		Category category = categoryService.getCategoryByID(categoryId);
		food.setCategory(category);
		return foodRepository.save(food);
	}

	@Override
	public Food updateFood(Food food, long foodId) {
		// TODO Auto-generated method stub
		Food food1 = getFoodById(foodId);
		food1.setFoodName(food.getFoodName());
		food1.setPrice(food.getPrice());
	    return foodRepository.save(food1);
	}
	
}

