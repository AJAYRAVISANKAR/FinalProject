package com.example.fooddeliveryproject.service;

import java.util.List;

import javax.validation.Valid;

import com.example.fooddeliveryproject.model.Food;

public interface FoodService {

	Food saveFood(Food food);

	List<Food> getFood();

	//void deleteCategoryById(long foodId);

	Food getFoodById(long foodId);

	void deleteFoodById(long foodId);

	Food addFoodToCategory(@Valid Food food, long categoryId);

	Food updateFood(Food food, long foodId);

	List<Food> getFoodByCategoryId(long categoryId);

	//void deleteFoodById(long foodId);

}
