package com.example.fooddeliveryproject.respository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.fooddeliveryproject.model.User;

@Repository
	public interface UserRepository extends JpaRepository<User, Long>{
		Optional<User> findByEmailIDAndPassword(String emailID,String password);
		//Optional<User> findByEmailID(String emailID);

		Optional<User> findByEmailID(String emailID);
		@Transactional
		void  deleteByEmailID(String emailID);

	}

