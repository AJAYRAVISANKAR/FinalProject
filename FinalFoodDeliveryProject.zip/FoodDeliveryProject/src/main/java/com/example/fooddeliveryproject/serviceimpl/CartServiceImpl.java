package com.example.fooddeliveryproject.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.fooddeliveryproject.exception.UserNotFoundException;
import com.example.fooddeliveryproject.model.Cart;
import com.example.fooddeliveryproject.model.Category;
import com.example.fooddeliveryproject.model.Food;
import com.example.fooddeliveryproject.model.User;
import com.example.fooddeliveryproject.respository.CartRepository;
import com.example.fooddeliveryproject.respository.CategoryRepository;
import com.example.fooddeliveryproject.service.CartService;
import com.example.fooddeliveryproject.service.CategoryService;
import com.example.fooddeliveryproject.service.FoodService;
import com.example.fooddeliveryproject.service.UserService;



	
	@Service
	public class CartServiceImpl implements CartService {

		@Autowired
		private CartRepository cartRepository;
		private FoodService foodService;
		private UserService userService;
		
		
		

		

		public CartServiceImpl(CartRepository cartRepository, FoodService foodService, UserService userService) {
			super();
			this.cartRepository = cartRepository;
			this.foodService = foodService;
			this.userService = userService;
		}

		@Override
		public Cart saveCart(Cart cart) {
			// TODO Auto-generated method stub
			System.out.println("In service"+ cart);
			return cartRepository.save(cart);
		}

		@Override
		public List<Cart> getCart() {
			// TODO Auto-generated method stub
			return cartRepository.findAll()  ;
		}

		@Override
		public Cart getCartById(long cartId) {
			// TODO Auto-generated method stub
			//return cartRepository.findById(cartId).orElseThrow(()->new UserNotFoundException("Cart","CartId",cartId)); 
			return cartRepository.findById(cartId).orElseThrow(()->new UserNotFoundException("Cart","CartId",cartId));
		}

		@Override
		public void deleteCartById(long cartId) {
			// TODO Auto-generated method stub
			cartRepository.findById(cartId).orElseThrow(()->new UserNotFoundException("Cart","CartId",cartId)); 
			cartRepository.deleteById(cartId);
		}
		@Override
		public Cart addFoodToCart(Cart cart, long foodId,String userEmailId) {
			// TODO Auto-generated method stub
			Food food=foodService.getFoodById(foodId);
			User user=userService.getUserByEmailID(userEmailId);
			
			cart.setFood(food);
			cart.setUser(user);
			return cartRepository.save(cart);
		}

		@Override
		public List<Cart> getCartByuserEmailId(String userEmaiID) {
			// TODO Auto-generated method stub
			 
			return cartRepository.findByUserEmailID(userEmaiID);
			//return null;
		}

		
	}

