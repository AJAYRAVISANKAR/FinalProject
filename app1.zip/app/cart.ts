export class Cart {
    constructor (
        public cartId: number,

        public quantity: number,

        public foodId: number,

        //public emailID: string

    ) {

    }
}