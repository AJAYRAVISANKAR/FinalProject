package com.example.fooddeliveryproject.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.fooddeliveryproject.exception.UserNotFoundException;
import com.example.fooddeliveryproject.model.User;
import com.example.fooddeliveryproject.respository.UserRepository;
import com.example.fooddeliveryproject.service.UserService;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
private UserRepository userRepository;
	
	 public UserServiceImpl(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}
 
	@Override
	public User saveUser(User user) {
		System.out.println("SideService");
		return userRepository.save(user);
	}
	@Override
	public User loginUser(User user) {
		
		return this.userRepository.findByEmailIDAndPassword(user.emailID,user.password).orElseThrow(()->new UserNotFoundException("User ", "EmailId", user.emailID+" and password "+user.password) );
	}
	

	@Override
	public List<User> getUser() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public User getUserByEmailID(String emailID) {
		// TODO Auto-generated method stub
		return userRepository.findByEmailID(emailID).orElseThrow(()->new UserNotFoundException("User","EmailID",emailID));

	}

	@Override
	public void deleteUser(String emailID) {
		// TODO Auto-generated method stub
		  userRepository.findByEmailID(emailID).orElseThrow(()->new UserNotFoundException("User","EmailID",emailID));
		  userRepository.deleteByEmailID(emailID);
	}

	@Override
	public User updateUser(User user, String emailID) {
		// TODO Auto-generated method stub
		User existingUser=userRepository.findByEmailID(emailID).orElseThrow(()->new UserNotFoundException("User","EmailID",emailID));
		existingUser.setFirstName(user. getFirstName());
		existingUser.setLastName(user.getLastName());
		existingUser.setPassword(user.getPassword());
		existingUser.setRole(user.getRole());
		existingUser.setMobile_No(user.getMobile_No());
		existingUser.setState(user.getState());
		existingUser.setZipCode(user.getZipCode());
		existingUser.setStreet (user.getStreet());
	
		userRepository.save(existingUser);
		return existingUser;
	}
}

	

