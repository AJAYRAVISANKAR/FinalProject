package com.example.fooddeliveryproject.service;

import java.util.List;

import com.example.fooddeliveryproject.model.Category;

public interface CategoryService {

	List<Category> getCategory();

	void deleteCategoryByID(long categoryID);

	Category getCategoryByID(long categoryID);

	Category saveCategory(Category category);

	Category updateCategoryById(long categoryId, Category category);
	

}
