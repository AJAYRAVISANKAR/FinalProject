export class Order {
    constructor(
        public orderId: number,

        public cartId: number,

        public totalPrice: number

    ) {

    }
}