package com.example.fooddeliveryproject.service;

import java.util.List;

import com.example.fooddeliveryproject.model.User;

//import antlr.collections.List;

public interface UserService {

	
		User saveUser(User user);
		User loginUser(User user);
	/*	user updateuser(Customer customer,long id);
		Customer getCustomerById(long id);
		List<Customer> getAllCustomers();
		Customer getCustomerByEmail(Customer customer);
		void deleteCustomer(long id);*/
		List <User>  getUser();
		User getUserByEmailID(String emailID);
		User updateUser(User user, String emailID);
		void deleteUser(String emailID);

	}

